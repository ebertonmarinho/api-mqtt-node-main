import Server from './Server.js';

const server = new Server(3000);
server.initialize();